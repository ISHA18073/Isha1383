#include <iostream>
#include <vector>

int knapsack(std::vector<int>& values, std::vector<int>& weights, int capacity)
{
    int n = values.size();

    // Create a 2D array to store the maximum value that can be obtained
    // using the first i items and a knapsack of j capacity
    std::vector<std::vector<int>> dp(n + 1, std::vector<int>(capacity + 1, 0));

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= capacity; j++) {
            if (weights[i - 1] <= j) {
                // If the i-th item can fit in the knapsack, we have two options:
                // either we include it, or we don't include it
                dp[i][j] = std::max(dp[i - 1][j], values[i - 1] + dp[i - 1][j - weights[i - 1]]);
            } else {
                // If the i-th item cannot fit in the knapsack, we cannot include it
                dp[i][j] = dp[i - 1][j];
            }
        }
    }

    // The maximum value that can be obtained is stored in the bottom-right corner of the dp table
    return dp[n][capacity];
}

int main()
{
    std::vector<int> values = { 60, 100, 120 };
    std::vector<int> weights = { 10, 20, 30 };
    int capacity = 50;

    int max_value = knapsack(values, weights, capacity);

    std::cout << "Maximum value that can be obtained: " << max_value << std::endl;

    return 0;
}
