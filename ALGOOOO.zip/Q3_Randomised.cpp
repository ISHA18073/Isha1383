#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

template<class T> class QuickSort {
    int size;
    int comparisons;
    T* array;
    
    public:
        QuickSort(int size) {
            this->size = size;
            comparisons = 0;
            array = new T[size];
            for (int i = 0; i < size; i++) {
                cout << "Enter Element [" << i+1 << "]: ";
                cin >> array[i];
            }
            sort(0, size-1);
            cout << "\n Total Comparisons: " << comparisons << endl;
            cout << "Sorted Array :- " ;
            for (int i = 0; i < size; i++) {
                cout << array[i] << " ";
            }
        }

        T rpartition(int beg, int end) {
            srand(time(NULL));
            int i = beg + rand()%(end - beg +1);
            cout << array[i] << " - Pivot" << endl;
            swap(array[end],array[i]);
            return partition(beg, end);
        }

        T partition(int beg, int end) {
            T x = array[end];
            int i = beg - 1;
            for (int j = beg; j < end ; j++) {
                comparisons++;
                if(array[j] <= x) {
                    i=i+1;
                    swap(array[j], array[i]);
                }
            }
            swap(array[i+1], array[end]);
            return i+1;
        }

        void sort(int beg, int end) {
            if(beg < end){
                int p = rpartition(beg, end);
                sort(beg, p - 1);
                sort(p + 1, end);
            }
        }
};

int main(){
    int n;
    cout<<"Enter the number of elements in the array : ";
    cin >> n;
    QuickSort<int> m(n);
}