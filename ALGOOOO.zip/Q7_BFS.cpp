#include <iostream>
#include <list>
#include <queue>
using namespace std;

template<class t> class Graph
{
    private:
        int V;
        list<t> *adj;
    public:
        Graph(int v){
            V=v;
            adj = new list<t>[V];
        }
        void addEdge(int u, int v){
            adj[u].push_back(v);
        }

        void printGraph() {
            for (int d = 0; d < V; ++d) {
                cout << "\nVertex " << d << ":";
                for (int i : adj[d]){
                    cout << "-> " << i;
                }
            }
        }

        /*void create(){
            t u;int n;
            cout << " Enter The Data of Graph ";
            for(int i = 0 ; i < V ; ++i){
                cout << "Enter The Vertex :- " << endl;
                cin >> u;
                cout << "   Enter no of connections :- "<< endl;
                cin >> n;
                while ()
                {
                    /* code
                }}}*/

        void BFS(int start){
            int visited[V];
            for (int i=1;i<V;++i){
                visited[i]=false;
            }
            queue<int> q;
            q.push(start);
            visited[start] = true;
            while (!q.empty()){
                int front = q.front();
                cout << "Parent : " << front <<endl ;
                q.pop();
                for (t i : adj[front]){
                    if (!visited[i]){
                        cout << "   Child : ";
                        cout<< i;
                        q.push(i);
                        visited[i] = true;
                    }
                }
                cout<<endl;
            }
        }

};
int main()
{
    Graph<int> g(5);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 0);
    g.addEdge(1, 4);
    g.addEdge(1, 2);
    g.addEdge(1, 3);
    g.addEdge(2, 4);
    g.addEdge(2, 0);
    g.addEdge(2, 1);
    g.addEdge(4, 3);
    g.addEdge(4, 1);
    g.addEdge(4, 2);
    g.addEdge(3, 1);
    g.addEdge(3, 4);
    g.printGraph();
    cout<<endl;
    g.BFS(0);
    return 0;
}
